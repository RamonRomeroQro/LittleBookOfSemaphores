# The dining savages problem


+ Compile ```./compile.sh```

+ Create semaphores:
    ``` bash
    $ ./a.out

    ```

+ Create chef:
    ``` bash
    $ ./b.out [sizeOfPot]

    ```

+ Create savages:
    ``` bash
    $ ./c.out [amountOfSavages]

    ```